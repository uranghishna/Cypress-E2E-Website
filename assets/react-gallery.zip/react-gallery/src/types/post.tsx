export type Post = {
  id: number;
  desc: string;
  image: string;
};